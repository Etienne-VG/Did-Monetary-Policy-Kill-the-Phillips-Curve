%% Did Monetary Policy Kill The Phillips Curve? Some Simple Arithmetics
%                           Replication code
%
%      by D. Bergholt, F. Furlanetto and E. Vaccaro-Grange (2024)
%
% Please cite the published paper for use of the code.
% Corresponding author for this replication code:
% D. Bergholt (drago.bergholt@norges-bank.no).

%% THIS FILE: SIMULATE DATA FROM THE THEORETICAL MODEL

%% Housekeeping
clearvars
close all
clc

%% Setup

story = {'base'; 'kappa'; 'policy'; 'shocks'};
condi = {'d'; 's'};

% Baseline vs kappa story
thetaj = [0.75; 0.875]';
% Baseline vs policy story
phipij = [1.5; 3.0]';
% Baseline vs shocks story
demscalej = [1.0; 0.6]';

% Dummies which allow us to condition on demand vs supply shocks
dummy1j = [1; 0]';
dummy2j = [0; 1]';

%% Model simulations

for jj = 1:numel(story)
    % Baseline calibration
    theta = thetaj(1);
    phipi = phipij(1);
    demscale = demscalej(1);
    if jj == 2
        % Kappa story
        theta = thetaj(2);
    elseif jj == 3
        % Policy story
        phipi = phipij(2);
    elseif jj == 4
        % Shocks story
        demscale = demscalej(2);
    end
    for kk = 1:numel(condi)
        if kk == 1
            % Condition on demand shocks
            dummy1 = dummy1j(1);
            dummy2 = dummy2j(1);
        else
            % Condition on supply shocks
            dummy1 = dummy1j(2);
            dummy2 = dummy2j(2);
        end
        % Simulate data from model
        dynare Model noclearall
        % Store simulated, conditional data in structure
        data.(story{jj}).y.(condi{kk}) = y;
        data.(story{jj}).pi.(condi{kk}) = pi;
    end
    % Store realized, "unconditional" data in structure
    data.(story{jj}).y.t = data.(story{jj}).y.d + data.(story{jj}).y.s;
    data.(story{jj}).pi.t = data.(story{jj}).pi.d + data.(story{jj}).pi.s;
end

% Save structure in mat-file
save('SimulatedData.mat','data')
