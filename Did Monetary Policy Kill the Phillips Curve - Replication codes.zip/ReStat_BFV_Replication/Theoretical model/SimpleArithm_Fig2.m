%% Did Monetary Policy Kill The Phillips Curve? Some Simple Arithmetics
%                           Replication code
%
%      by D. Bergholt, F. Furlanetto and E. Vaccaro-Grange (2024)
%
% Please cite the published paper for use of the code.
% Corresponding author for this replication code:
% D. Bergholt (drago.bergholt@norges-bank.no).

%% THIS FILE: FIGURE 2 - ALTERNATIVE EXPLANATIONS, SIMULATED DATA

%% Housekeeping
clearvars
clc

%addpath('Simulations');

%% Options

load('SimulatedData.mat')

condi = {'t';'d';'s'};
titles = {'Unconditional'; ...
    'Conditional on demand'; ...
    'Conditional on supply'; ...
    };

SimpleArithm_Options;

%% Plot simulated data

story = {'kappa'; 'policy'; 'shocks'};
for hh = 1:numel(story)
    figure; clf
    for ii = 1:numel(condi)
        sub.h(1) = subplot(3,4,4*ii-3);
        hold on
        regime = {'base'; story{hh}};
        for jj = 1:numel(regime)
            plot(data.(regime{jj}).y.(condi{ii}),data.(regime{jj}).pi.(condi{ii}),'o','color',opt.col(jj,:))
            b = fitlm(data.(regime{jj}).y.(condi{ii}),data.(regime{jj}).pi.(condi{ii}));
            plot([min(data.(regime{jj}).y.(condi{ii}));max(data.(regime{jj}).y.(condi{ii}))],b.predict([min(data.(regime{jj}).y.(condi{ii}));max(data.(regime{jj}).y.(condi{ii}))]),'-','color',opt.col(jj,:),'linewidth',opt.lw(1))
        end
        ylim(1.1*[min([data.base.pi.(condi{ii});data.(story{hh}).pi.(condi{ii})]) max([data.base.pi.(condi{ii});data.(story{hh}).pi.(condi{ii})])])
        xlim(1.1*[min([data.base.y.(condi{ii});data.(story{hh}).y.(condi{ii})]) max([data.base.y.(condi{ii});data.(story{hh}).y.(condi{ii})])])
        hold off
        set(sub.h(1),'fontsize',opt.fs)
        title(strcat(titles{ii}), 'fontsize', opt.fs-3,'fontweight','normal')
        ylabel('$\pi_t$','interpreter','latex','fontsize',opt.fs)
        xlabel('$y_t$','interpreter','latex','fontsize',opt.fs)
    end
end
