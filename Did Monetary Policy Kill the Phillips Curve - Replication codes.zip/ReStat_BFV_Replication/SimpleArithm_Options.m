%% Did Monetary Policy Kill The Phillips Curve? Some Simple Arithmetics
%                           Replication code
%
%      by D. Bergholt, F. Furlanetto and E. Vaccaro-Grange (2024)
%
% Please cite the published paper for use of the code. Comments and
% questions can be sent to D. Bergholt (drago.bergholt@norges-bank.no).

%% Options
opt.fs = 20;
opt.sz = 108;
opt.col = [ ...
    0.45 0.45 0.45; ...
    0.75 0.75 0.75 ...
    ];
opt.lw = [2.5; 1];
opt.ls = {'--'; '-'};