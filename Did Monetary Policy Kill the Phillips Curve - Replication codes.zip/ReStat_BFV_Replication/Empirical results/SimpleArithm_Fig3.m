%% Did Monetary Policy Kill The Phillips Curve? Some Simple Arithmetics
%                           Replication code
%
%      by D. Bergholt, F. Furlanetto and E. Vaccaro-Grange (2024)
%
% Please cite the published paper for use of the code.
% Corresponding author for this replication code:
% D. Bergholt (drago.bergholt@norges-bank.no).

%% THIS FILE: FIGURE 3 - EMPIRICAL SCATTER PLOTS

%% Prepare data

dataset = {'conditional_data_median_draw_model_1.1.mat'; ...
           'conditional_data_median_draw_model_1.2.mat'};

vars = {'pi'; 'ygap'};
cond = {'u'; 'd'; 's'};
SelectColumn = [8; 9; 2; 3; 4; 5];

PrepData;

%% Compute and plot projection coefficients

for jj = 1:length(cond)
    R.betta.(cond{jj}) = [ones(length(D.ygap.(cond{jj})),1),D.d2,D.ygap.(cond{jj}),D.d2.*D.ygap.(cond{jj})] \ (D.pi.(cond{jj}));
    R.pipred.(cond{jj}) = D.pi.(cond{jj}) - R.betta.(cond{jj})(1)*ones(length(D.ygap.(cond{jj})),1) - R.betta.(cond{jj})(2)*D.d2;
end

for jj = 1:length(cond)
    x1 = D.ygap.(cond{jj})(1:t1);
    y1 = R.pipred.(cond{jj})(1:t1);
    x2 = D.ygap.(cond{jj})(t1+1:end);
    y2 = R.pipred.(cond{jj})(t1+1:end);
    b1 = x1 \ y1;
    b2 = x2 \ y2;

% Scatter plots
    figure; clf
    subplot(1,2,1);
    hold on
    scatter(x1,y1,opt.sz, ...
        opt.col(1,:),'linewidth',opt.lw(1),'markerfacecolor',opt.col(1,:),'MarkerFaceAlpha',.8,'MarkerEdgeAlpha',0)
    lineA = plot([min(x1);max(x1)],[min(x1);max(x1)] * b1, ...
        'linestyle','-','linewidth',opt.lw(1),'color',opt.col(1,:));
    scatter(x2,y2, ...
        opt.sz,opt.col(2,:),'linewidth',opt.lw(1),'markerfacecolor',opt.col(2,:),'MarkerFaceAlpha',.8,'MarkerEdgeAlpha',0)
    lineB = plot([min(x2);max(x2)],[[min(x2);max(x2)]] * b2, ...
        'linestyle','-','linewidth',opt.lw(1),'color',opt.col(2,:));
    
    ylabel('Inflation','FontSize',opt.fs)
    xlabel('Output gap','FontSize',opt.fs)
    set(gca,'FontSize',opt.fs)
    if jj == 1
        hL = legend([lineA, lineB], ...
            {'1969Q1-1994Q4', ...
            '1995Q1-2019Q4'}, ...
            'FontSize', opt.fs-2);
        set(hL,'Units', 'normalized', 'Box', 'off');
    end
end
