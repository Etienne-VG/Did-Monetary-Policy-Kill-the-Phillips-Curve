%% Did Monetary Policy Kill The Phillips Curve? Some Simple Arithmetics
%                           Replication code
%
%      by D. Bergholt, F. Furlanetto and E. Vaccaro-Grange (2024)
%
% Please cite the published paper for use of the code.
% Corresponding author for this replication code:
% D. Bergholt (drago.bergholt@norges-bank.no).

%% THIS FILE: FIGURE 4c - HISTORICAL SHOCK DECOMPOSITIONS

%% Prepare data

dataset = {'conditional_data_median_draw_model_1.1.mat'; ...
    'conditional_data_median_draw_model_1.2.mat'};

vars = {'pi'; 'ygap'};
cond = {'u'; 'd'; 's'; 'i'};
SelectColumn = [8; 9; 2; 3; 4; 5; 6; 7];

PrepData;

%% Choose sample to plot

hvd_start = 102;
hvd_end = length(D.ygap.u);
period = D.time;

%% Store in structures

for jj = 1:length(vars)
    hvd.(vars{jj}).p = [D.(vars{jj}).d, D.(vars{jj}).s, D.(vars{jj}).i];
    hvd.(vars{jj}).n = [D.(vars{jj}).d, D.(vars{jj}).s, D.(vars{jj}).i];
    hvd.(vars{jj}).p(hvd.(vars{jj}).p<0) = nan;
    hvd.(vars{jj}).n(hvd.(vars{jj}).n>=0) = nan;
end

%% Plot historical decompositions

varstit = {'INFLATION'; 'OUTPUT GAP'};
condtit = {'DEMAND'; 'SUPPLY'; 'INITIAL COND.'};

figure; clf;
for jj = 1:2
    figsub(jj) = subplot(2,2,2+jj);
    hold on;
    b1 = bar(period(hvd_start:hvd_end)',[hvd.(vars{jj}).p(hvd_start:hvd_end,2,1), hvd.(vars{jj}).p(hvd_start:hvd_end,1,1)], 0.95, 'stacked');
    b2 = bar(period(hvd_start:hvd_end)',[hvd.(vars{jj}).n(hvd_start:hvd_end,2,1), hvd.(vars{jj}).n(hvd_start:hvd_end,1,1)], 0.95, 'stacked');
    plot(period(hvd_start:hvd_end), D.(vars{jj}).d(hvd_start:hvd_end)+D.(vars{jj}).s(hvd_start:hvd_end),'-','LineStyle', '-', 'Color', [0 0 0], 'LineWidth', opt.lw(1));
    title(strcat([varstit{jj}]), 'FontSize', opt.fs, 'FontWeight', 'normal')
    if jj == 1
        legend({'SUPPLY','DEMAND'}, 'FontSize', opt.fs, 'Orientation', 'horizontal', 'Box', 'off', 'Position', [0.45,0.005,0.15,0.05]);
    end
    b1(1).FaceColor = opt.col(2,:);
    b2(1).FaceColor = opt.col(2,:);
    b1(2).FaceColor = opt.col(1,:);
    b2(2).FaceColor = opt.col(1,:);
    b1(1).EdgeColor = 'none';
    b2(1).EdgeColor = 'none';
    b1(2).EdgeColor = 'none';
    b2(2).EdgeColor = 'none';
    axis tight
    set(figsub(jj),'fontsize',opt.fs)
end