%% Did Monetary Policy Kill The Phillips Curve? Some Simple Arithmetics
%                           Replication code
%
%      by D. Bergholt, F. Furlanetto and E. Vaccaro-Grange (2024)
%
% Please cite the published paper for use of the code.
% Corresponding author for this replication code:
% D. Bergholt (drago.bergholt@norges-bank.no).

%% THIS FILE: FIGURE 1 - DATA

%% Prepare data

dataset = {'conditional_data_median_draw_model_1.1.mat'; ...
           'conditional_data_median_draw_model_1.2.mat'};

vars = {'pi'; 'ygap'};
cond = {'u'};
SelectColumn = [8; 9];

PrepData;

SimpleArithm_Options;

%% Plot data

figure; clf
hold on
h1 = plot(D.time,D.pi.u,'-','LineStyle', '-', 'Color', opt.col(2,:), 'LineWidth', opt.lw(1));
h2 = plot(D.time,D.ygap.u,'-','LineStyle', '-.', 'Color', opt.col(1,:), 'LineWidth', opt.lw(1));

hL = legend([h1, h2], ...
    {'INFLATION', ...
    'OUTPUT GAP'}, ...
    'FontSize', opt.fs);
    newUnits = 'normalized';
    set(hL,'Units', newUnits,'Box','off');
set(gca,'fontsize',opt.fs,'YGrid','on','XGrid','off')
