%% Prepare data

samp = {'s1'; 's2'};

for jj = 1:length(samp)
    load(dataset{jj});
    D.(samp{jj}).time = cell2mat(conditional_data_median_draw(2:end,1));
    mm = 0;
    for kk = 1:length(cond)
        for ll = 1:length(vars)
            mm = mm + 1;
            D.(samp{jj}).(vars{ll}).(cond{kk}) = cell2mat(conditional_data_median_draw(2:end,SelectColumn(mm)));
        end
    end
end

D.time = [D.s1.time;D.s2.time];
for jj = 1:length(vars)
    for kk = 1:length(cond)
        D.(vars{jj}).(cond{kk}) = [D.s1.(vars{jj}).(cond{kk});D.s2.(vars{jj}).(cond{kk})];
    end
end

t1 = length(D.s1.time);
t2 = length(D.s2.time);
D.d2 = [zeros(length(D.s1.pi.u),1);ones(length(D.s2.pi.u),1)];

D=rmfield(D,{'s1','s2'});
clear conditional_data_median_draw jj kk ll mm SelectColumn
