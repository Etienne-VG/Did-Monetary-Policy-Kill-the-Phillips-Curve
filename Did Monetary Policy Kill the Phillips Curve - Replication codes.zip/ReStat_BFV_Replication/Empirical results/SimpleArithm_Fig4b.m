%% Did Monetary Policy Kill The Phillips Curve? Some Simple Arithmetics
%                           Replication code
%
%      by D. Bergholt, F. Furlanetto and E. Vaccaro-Grange (2024)
%
% Please cite the published paper for use of the code.
% Corresponding author for this replication code:
% D. Bergholt (drago.bergholt@norges-bank.no).

%% THIS FILE: FIGURE 4b - PHILLIPS MULTIPLIERS

%% Prepare data

dataset = {'conditional_data_median_draw_model_1.1.mat'; ...
           'conditional_data_median_draw_model_1.2.mat'};

vars = {'pi'; 'ygap'};
cond = {'u'; 'd'; 's'};
SelectColumn = [8; 9; 2; 3; 4; 5];

PrepData;

%% Collect cumulative, conditional data

% Horizons to plot
HH = 8;

for hh = 0:HH
    for jj = 1:length(cond)
        for tt = 1:length(D.ygap.(cond{jj}))-hh
            D.ygapcum.(cond{jj})(tt,hh+1) = sum(D.ygap.(cond{jj})(tt:tt+hh));
            D.picum.(cond{jj})(tt,hh+1) = sum(D.pi.(cond{jj})(tt:tt+hh));
        end
    end
end

for ii = 1:length(cond)
    for jj = 1:size(D.ygapcum.u,2)
        hori{jj} = strcat('pm',num2str(jj));
        D.ygapcum2.(cond{ii}).(hori{jj}) = [D.ygapcum.(cond{ii})(1:length(D.d2) - sum(D.d2) - (jj - 1),jj); D.ygapcum.(cond{ii})(length(D.d2) - sum(D.d2) + 1:end - (jj - 1),jj)];
        D.picum2.(cond{ii}).(hori{jj}) = [D.picum.(cond{ii})(1:length(D.d2) - sum(D.d2) - (jj - 1),jj); D.picum.(cond{ii})(length(D.d2) - sum(D.d2) + 1:end - (jj - 1),jj)];
    end
end

for jj = 1:size(D.ygapcum.u,2)
    D.dummy2.(hori{jj}) = [D.d2(1:length(D.d2) - sum(D.d2) - (jj - 1)); D.d2(length(D.d2) - sum(D.d2) + 1:end - (jj - 1))];
end

%% Estimate conditional Phillips coefficients betta_h at horizon h

for jj = 1:length(cond)
    for kk = 1:size(D.ygapcum.u,2)
        X = [D.dummy2.(hori{kk}), (1 - D.dummy2.(hori{kk})).*D.ygapcum2.(cond{jj}).(hori{kk}), D.dummy2.(hori{kk}).*D.ygapcum2.(cond{jj}).(hori{kk})];
        Y = D.picum2.(cond{jj}).(hori{kk});
        mdl = fitlm(X,Y);
        [EstCoeffCovHac,seHac,coeffHac] = hac(mdl);
        betta.(cond{jj})(:,kk) = coeffHac;
        se.(cond{jj})(:,kk) = seHac;
        cil.(cond{jj})(:,kk) = betta.(cond{jj})(:,kk) - 1.65*se.(cond{jj})(:,kk);
        cih.(cond{jj})(:,kk) = betta.(cond{jj})(:,kk) + 1.65*se.(cond{jj})(:,kk);
    end
end

%% Plot Phillips multipliers

figure; clf
for jj = 1:length(cond)
    subplot(2,3,jj);
    hold on
    for kk = 1:2 % Multipliers for two samples
        fill([[0:size(D.ygapcum.(cond{jj}),2)-1], fliplr([0:size(D.ygapcum.(cond{jj}),2)-1])], [cil.(cond{jj})(kk+2,:), fliplr(cih.(cond{jj})(kk+2,:))], 1,'facecolor', opt.col(kk,:), 'edgecolor', 'none', 'facealpha', 0.2);
        plot([0:HH]',[cih.(cond{jj})(kk+2,:)',cil.(cond{jj})(kk+2,:)'],'linewidth',opt.lw(2),'linestyle',opt.ls{kk},'color',opt.col(1,:));
        h(kk) = plot([0:HH]',[betta.(cond{jj})(kk+2,:)'],'linewidth',opt.lw(1),'linestyle',opt.ls{kk},'color',opt.col(1,:));
    end
    plot([0:HH]',[zeros(length(betta.(cond{jj})(4,:)'),1)], ':', 'color', [0 0 0]);
    if jj < 3
        ylim([-0.2,1.0])
    end
    set(gca,'FontSize',opt.fs)
    
    if jj == 1
        hL = legend([h(1), h(2)], ...
            {'1969Q1-1994Q4', ...
            '1995Q1-2019Q4'}, ...
            'FontSize', opt.fs);
        newUnits = 'normalized';
        set(hL,'Units', newUnits,'Box','off');
    end
end