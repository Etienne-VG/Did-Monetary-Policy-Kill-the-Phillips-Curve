%% Did Monetary Policy Kill The Phillips Curve? Some Simple Arithmetics
%                           Replication code
%
%      by D. Bergholt, F. Furlanetto and E. Vaccaro-Grange (2024)
%
% Please cite the published paper for use of the code.
% Corresponding author for this replication code:
% D. Bergholt (drago.bergholt@norges-bank.no).

%% THIS FILE: TABLE 2 - ROBUSTNESS EXERCISES

%% Specifications (a)-(l)

Mdls = 1:12;

% Choose model specifictaions in Mdls.
% Example: Sample-specific data for specification (f) are stored in
% conditional_data_median_draw_model_6.1.mat and
% conditional_data_median_draw_model_6.2.mat, respectively.

for qq = Mdls
    dataset = { ...
    strcat('conditional_data_median_draw_model_',num2str(qq),'.1.mat'); ...
    strcat('conditional_data_median_draw_model_',num2str(qq),'.2.mat') ...
    };
    dataset_fevd = { ...
    strcat('FEVD_median_draw_model_',num2str(qq),'.1.mat'); ...
    strcat('FEVD_median_draw_model_',num2str(qq),'.2.mat') ...
    };

vars = {'pi'; 'ygap'};

if qq <=6
    % Specifications (a)-(f):
    cond = {'u'; 'd'; 's'};
    SelectColumn = [8; 9; 2; 3; 4; 5];
    for kk = 1:2
        load(dataset_fevd{kk});
        x(kk,1) = cell2mat(FEVD_median_draw(25,5));
    end
elseif qq <= 9
    % Specifications (g)-(i):
    cond = {'u'; 'd'; 's'};
    SelectColumn = [14; 15; 2; 3; 5; 6];
    for kk = 1:2
        load(dataset_fevd{kk});
        x(kk,1) = cell2mat(FEVD_median_draw(25,9));
    end
elseif qq <=11
    % Specifications (j)-(k):
    cond = {'u'; 'd'; 'm'; 's'};
    SelectColumn = [14; 15; 2; 3; 8; 9; 5; 6];
    for kk = 1:2
        load(dataset_fevd{kk});
        x(kk,1) = cell2mat(FEVD_median_draw(25,6));
    end
else
    % Specification (l):
    cond = {'u'; 'd'; 'm'; 's'; 'ls'};
    SelectColumn = [22; 23; 2; 3; 14; 15; 6; 7; 10; 11];
    for kk = 1:2
        load(dataset_fevd{kk});
        x(kk,1) = cell2mat(FEVD_median_draw(25,7)) + cell2mat(FEVD_median_draw(25,8));
    end
end

PrepData;

%%

disp(cell2mat(strcat('SPECIFICATION ',{' '},num2str(qq),':')))
fprintf(1, '\n');

disp('Phillips correlations in sample 1 and sample 2:')
for jj = 1:length(cond)
    OLSreg.(cond{jj}) = fitlm([D.d2 D.ygap.(cond{jj}) D.d2.*D.ygap.(cond{jj})],D.pi.(cond{jj}));
    disp([num2str(OLSreg.(cond{jj}).Coefficients.Estimate(3),'%4.2f') ' ' num2str(OLSreg.(cond{jj}).Coefficients.Estimate(3)+OLSreg.(cond{jj}).Coefficients.Estimate(4),'%4.2f')]);
end
disp('VD(y|supply) in sample 1 and sample 2:')
disp([num2str(x(1),'%4.2f') ' ' num2str(x(2),'%4.2f')]);
fprintf(1, '\n');

disp('The following conditional datasets have been used:')
display(dataset{1})
display(dataset{2})
display(dataset_fevd{1})
display(dataset_fevd{2})
fprintf(1, '\n');
fprintf(1, '\n');
fprintf(1, '\n');

end