%% Did Monetary Policy Kill The Phillips Curve? Some Simple Arithmetics
%                           Replication code
%
%      by D. Bergholt, F. Furlanetto and E. Vaccaro-Grange (2024)
%
% Please cite the published paper for use of the code.
% Corresponding author for this replication code:
% D. Bergholt (drago.bergholt@norges-bank.no).

%% THIS FILE: FIGURE 4a - VARIANCE DECMPOSITION

%% Prepare data

for kk = 1:2
    load(strcat('FEVD_median_draw_model_1.',num2str(kk),'.mat'));
    x(kk,1) = cell2mat(FEVD_median_draw(25,5));
end

%% Plot sample-specific var(y|supply) as share of total

figure; clf
ba = bar([1-x(1) x(1); 1-x(2) x(2)],'stacked','FaceColor','flat');
ba(1).CData = opt.col(1,:);
ba(2).CData = opt.col(2,:);
ba(1).EdgeColor = 'none';
ba(2).EdgeColor = 'none';
ylabel('VARIANCE DECOMPOSITION, OUTPUT GAP')
set(gca,'xticklabel',{'1969Q1-1994Q4', '1995Q1-2019Q4'})
set(gca,'FontSize',opt.fs)

    hL = legend([ba(2), ba(1)], ...
            {'SUPPLY', ...
            'DEMAND'}, ...
            'FontSize', opt.fs);
        newUnits = 'normalized';
        set(hL,'Units', newUnits,'Box','off');
