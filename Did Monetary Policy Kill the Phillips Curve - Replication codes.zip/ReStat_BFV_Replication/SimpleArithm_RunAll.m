%% Did Monetary Policy Kill The Phillips Curve? Some Simple Arithmetics
%                           Replication code
%
%      by D. Bergholt, F. Furlanetto and E. Vaccaro-Grange (2024)
%
% Please cite the published paper for use of the code.
% Corresponding author for this replication code:
% D. Bergholt (drago.bergholt@norges-bank.no).

%% This file reproduces all figures and table results in the paper.

%% Housekeeping
close all
clearvars
clc

addpath(genpath('Theoretical model'));
addpath('Empirical results');
addpath('VAR estimation/Results');

SimpleArithm_Options;

%% Figure 1: Data

SimpleArithm_Fig1;

%% Figure 2: Alternative explanations in simulated data

SimpleArithm_Fig2;

%% Figure 3: Empirical scatterplots

SimpleArithm_Fig3;

%% Figure 4: Complementary empirical evidence

% Figure 4(a): Variance decomposition of CBO�s output gap
SimpleArithm_Fig4a;

% Figure 4(b): Phillips multipliers
SimpleArithm_Fig4b;

% Figure 4(c): A historical shock decomposition of data
SimpleArithm_Fig4c;

%% Table 2: Robustness exercises

SimpleArithm_Tab2;
