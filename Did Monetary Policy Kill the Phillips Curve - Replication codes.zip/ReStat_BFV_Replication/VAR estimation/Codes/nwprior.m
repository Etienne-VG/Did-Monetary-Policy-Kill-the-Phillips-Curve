function [B0,beta0,phi0,S0,alpha0]=nwprior(infoZ)

% start with beta0, defined in (1.3.4)
beta0=zeros(infoZ.q,1);

% unvectorize (reshape) the vector to obtain the matrix B0
B0=reshape(beta0,infoZ.k,infoZ.n); % Psi_bar in ARW(2018)

% next compute phi0, the variance-covariance matrix of beta, defined in (1.4.7)
% set first phi0 as a k*k matrix of zeros
phi0=zeros(infoZ.k,infoZ.k); % Omega_bar in ARW (2018)

% now compute alpha0 from (1.4.12)
alpha0=0; % nu_bar in ARW (2018)

% and finally compute S0, depending on which choice has been made for the prior ((1.4.13) or identity)
S0=zeros(infoZ.n,infoZ.n); % Phi_bar in ARW (2018)

end