function []=fevd_save(fevd_record,endo,signreslabels,n,FEVD_horizon,datapath,It,model)

%% Build FEVD
FEVD_All=NaN(FEVD_horizon,n*n,It);

l=0;
% consider variables in turn 
for i=1:n
   % consider shocks in turn
   for j=1:n
       l=l+1;
       for k=1:It
           FEVD_All(:,l,k)=fevd_record{i,j}(k,:)';
       end
   end
end

%% Add names
names=cell(1,n*n+1);
names{1,1}='Horizon';
k=1;
for i=1:n
    for j=1:n
        k=k+1;
        names{1,k}=strcat(endo{i},{' '},signreslabels{j});
    end
end

FEVD_median_draw=[names;num2cell([[1:FEVD_horizon]',median(FEVD_All,3)])];
FEVD_all_draws=[repmat(names,1,1,It);num2cell([repmat([1:FEVD_horizon]',1,1,It),FEVD_All])];

%% Save slopes & intercepts
Filename_all_draws=strcat('FEVD_all_draws_model_',num2str(model),'.mat');
Filename_median=strcat('FEVD_median_draw_model_',num2str(model),'.mat');


cd(strcat(datapath,'/Results'));
save(Filename_all_draws,'FEVD_all_draws');
save(Filename_median,'FEVD_median_draw');
cd(strcat(datapath,'/Codes'));

end

