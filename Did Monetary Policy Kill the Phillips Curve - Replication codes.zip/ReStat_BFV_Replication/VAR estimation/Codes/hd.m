function hd_record=hd(strshocks_record,struct_irf_record,Y,n,T,It)

% preliminary tasks
% first create the hd_record and temp cells
hd_record=cell(n,n+1);
temp3=cell(n,2);

% step 5: compute the historical contribution of each shock
for ii=1:It % loop over draws
   for jj=1:n % loop over variables
      for kk=1:n % loop over shocks
          virf(:,1)=struct_irf_record{jj,kk}(ii,:)';
          vshocks=strshocks_record{kk,1}(ii,:)'; % step 4: create the virf and vshocks vectors
          for ll=1:T % loop over sample periods
              hd_record{jj,kk}(ii,ll)=virf(1:ll,1)'*flipud(vshocks(1:ll,1));
          end
      end
   end
end

% step 6: compute the contributions of deterministic variables
for ii=1:n % loop over rows of temp/hd_record
   % initial condition
   temp3{ii,1}=hd_record{ii,1};
   % sum over the remaining columns of hd_record
   for jj=2:n
       temp3{ii,1}=temp3{ii,1}+hd_record{ii,jj};
   end
   % fill the Y matrix in temp
   temp3{ii,2}=repmat(Y(:,ii)',It,1);
   % fill the Yd matrix in hd_record
   hd_record{ii,n+1}=temp3{ii,2}-temp3{ii,1};
   % go for next variable
end