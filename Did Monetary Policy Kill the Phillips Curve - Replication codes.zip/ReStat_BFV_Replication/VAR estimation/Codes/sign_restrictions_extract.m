function infoZ=sign_restrictions_extract(signrestable,signresperiods,infoZ)

% - cell 'signrestable': table recording the sign restriction input from the user
% - cell 'signresperiods': table containing the periods corresponding to each restriction

% Periods concerned with restrictions
nperiods=1;
periods=0:1;

% Identify the restriction matrices
Scell=cell(1,infoZ.n);
Zcell=cell(1,infoZ.n);
Zstructural=cell(1,infoZ.n);

% Check if value and periods restrictions correspond to each other
if sum(sum(~cellfun(@isempty,signresperiods) == ~cellfun(@isempty,signrestable))) == infoZ.n^2
    % All cells with sign restrictions also specify the horizon over which these are applied
else
    error('Warning: Value restrictions do not correspond to period restrictions one to one')
end

% loop over rows and columns of the period matrix
for jj=1:infoZ.n % loop over shocks
   for ii=1:infoZ.n % loop over variables
      % if entry (ii,jj) of the period matrix and of the value matrix is not empty...
      if ~isempty(signresperiods{ii,jj}) && ~isempty(signrestable{ii,jj})
         % ... then there is a restriction over one (or several) periods
         % loop overt those periods
         for kk=signresperiods{ii,jj}(1,1):signresperiods{ii,jj}(1,1) % :signresperiods{ii,jj}(1,2) before 0+ and 0- restrictions
             % identify the position of the considered period within the list of all periods (required to build the matrix)
             position=find(periods==kk);
             % now create the restriction matrix: this will depend on the type of restriction
            % if it is a positive sign restriction...
            if strcmp(signrestable{ii,jj},'+')
                % ... then input a 1 entry in the corresponding S matrix
                Scell{1,jj}=[Scell{1,jj};zeros(1,infoZ.n*nperiods)];
                Scell{1,jj}(end,ii)=1;
            
            % if it is a negative sign restriction...
            elseif strcmp(signrestable{ii,jj},'-')
                % ... then input a -1 entry in the corresponding S matrix
                Scell{1,jj}=[Scell{1,jj};zeros(1,infoZ.n*nperiods)];
                Scell{1,jj}(end,ii)=-1;
            end
         end
      end
   end
end

% Add proxy restrictions
[Zcell,Zstructural]=build_Zcell(Zcell,Zstructural,infoZ.n);

% Build dimensions
infoZ=build_dims(infoZ,Zcell);

% Gather in infoZ
infoZ.horizon=nperiods;
infoZ.periods=periods;
infoZ.nperiods=nperiods;
infoZ.Scell=Scell;
infoZ.Zcell=Zcell;
infoZ.Zstructural=Zstructural;

end