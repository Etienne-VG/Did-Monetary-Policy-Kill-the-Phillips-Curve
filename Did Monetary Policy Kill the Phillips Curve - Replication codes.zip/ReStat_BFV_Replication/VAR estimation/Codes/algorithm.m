function [beta_gibbs,sigma_gibbs,Q_gibbs,draw]=algorithm(infoZ,SBVAR)

% Pre-allocation
draw=0;
success=0;
beta_gibbs=[];
sigma_gibbs=[];
Q_gibbs=[];

while success==0

    %% Structural Drawing
    % Case zero restrictions, long-run restrictions, sign restrictions, Narrative sign restrictions, and Choleski identification
    Sigma=iwishrnd(SBVAR.Sbar,SBVAR.alphabar); % Sbar=S0 and alphabar=alpha0 in BEAR = Phi_tild & nu_tild in ARW (2018)

    % Step 1 in ARW (2018)
    Sigma=(Sigma'+Sigma)/2; % Sbar=S0 and alphabar=alpha0 in BEAR = Phi_tild & nu_tild in ARW (2018)
    cholSigma=chol(Sigma,'lower');
    kron_sigma_phibar = (kron(Sigma,SBVAR.phibar)'+kron(Sigma,SBVAR.phibar))/2; % ensure positive definite
    beta=mvnrnd(SBVAR.betabar,kron_sigma_phibar)'; % B is a draw from a multivariate normal distribution with mean Bbar and variance Sigma kron phibar.
    B=reshape(beta,infoZ.k,infoZ.n); % B is k*n with k=n*p+m as in BEAR Equation 1.1.7 Actually it is B'

    % Check if the draw is stationary, otherwise discard
    [stationary,~]=checkstable(B,infoZ.n,infoZ.p);
    if stationary==0
       continue;
    end
    
    % Step 2 Algo 2 in ARW (2018) (line 8 to 12 in ARW (2018) Supplement) if stationary    
    Q=drawQ(randn(infoZ.n,infoZ.n),1,infoZ.n);
    D=cholSigma*Q; % D=inv(A_0) in ARRW (2018)

    %% Check sgn restrictions, if any
    % Compute orthogonalized IRF (line 15 in ARRW (2018) Supplement)
    % In ARW (2018) version it is A_0 instead of D and A_plus instead of beta because he doesn't multiply the IRF by D in irfsim
    ortirfmatrix=D; % IRF on impact = D
    
    % Check if traditionnal sign restrictions are satisfied
    [success,~,fail_shock]=checksignres(ortirfmatrix,infoZ.Scell,infoZ.horizon); % Only works for restrictions on impact.

    % If not, try inverting the sign of the columns of Q for which the restriction is rejected
    if success==0
        temp=unique(fail_shock);
        for gg=temp
            Q(:,gg)=-Q(:,gg); 
        end   
        D=cholSigma*Q; % D=inv(A_0) in ARW (2018)
        % Compute IRFs
        ortirfmatrix=D; % IRF on impact = D
        % Check sign restrictions
        [success,~,~]=checksignres(ortirfmatrix,infoZ.Scell,infoZ.horizon); % Only works for restrictions on impact.
    end
       
   % Reduced-form coefficients
   beta_gibbs=beta;
   sigma_gibbs=D(:);
   Q_gibbs=Q(:);
   draw=draw+1;

end

end