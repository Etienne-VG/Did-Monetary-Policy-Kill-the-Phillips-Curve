function Q=drawQ(X,n1,n2)

[Q,R] = qr(X);
for j=n1:n2
    if R(j,j)<0
        Q(:,j)=-Q(:,j); % This is the normalization stated in Theorem 4 of ARRW (2018)
    end
end

end