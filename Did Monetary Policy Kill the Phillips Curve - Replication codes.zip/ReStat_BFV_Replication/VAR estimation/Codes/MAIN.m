%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% DID MONETARY POLICY KILL THE PHILLIPS CURVE? SOME SIMPLE ARITHMETICS %%
%%%% DRAGO BERGHOLT, FRANCESCO FURLANETTO AND ETIENNE VACCARO-GRANGE %%%%%
%%%%%%%%%% Correspondance for the code: evaccaro-grange@imf.org %%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Housekeeping
clear;
close all;
warning off;
clc;
% Fix seed
rng(0);

% Path to excel data file
datapath = cd;
idcs = strfind(datapath,'\'); % PC
%idcs = strfind(datapath,'/'); % MAC
datapath = datapath(1:idcs(end)-1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% models to run
%MODEL_TO_RUN=3; % run the baseline model only
MODEL_TO_RUN=1:12; % run all model in a loop
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Just to add 1 and 2 in the model number for the 1st and 2nd samples
all_models=[];
for i=1:size(MODEL_TO_RUN,2)
   all_models=[all_models,MODEL_TO_RUN(1,i)+0.1,MODEL_TO_RUN(1,i)+0.2];
end

%% Loop over models
for model=all_models

    % Display model run
    temp=num2str(model);
    disp(strcat('Running Model',{' '},temp(1:2),{' - Sample '},temp(end)));

    % Set setting options
    Settings;
    % Run a script to convert string into a list of endogenous, exogenous, and units (if applicable)
    convertstrngs;
    % Add path
    addpath(datapath);
    
    %% BLOCK 1: INITIALIZATION
    % Sign restrictions table
    [signrestable,signresperiods,signreslabels]=loadsignres(endo,round(model));
    % Generate the different sets of data
    [names,data_endo]=gensample(startdate,enddate,endo,round(model));
    % Generate the strings and decimal vectors of dates
    decimaldates=gendates(names,lags,startdate,enddate);
    % Build infoZ for convenience
    [infoZ,Y,X]=build_infoZ(data_endo,const,lags);
    
    %% BLOCK 2: POSTERIOR DERIVATION AND IRF
    % Set prior values
    [B0,beta0,phi0,S0,alpha0]=nwprior(infoZ);
    % Obtain posterior distribution parameters
    SBVAR=nwpost(B0,phi0,S0,alpha0,X,Y,infoZ);
    % Run Gibbs sampler and draw structural IRFs
    [beta_gibbs,sigma_gibbs,q_gibbs,struct_irf_record,count_draws]=Gibbs_sampler(infoZ,SBVAR,signrestable,signresperiods,It);
        
    %% BLOCK 3: STRUCTURAL SHOCKS
    strshocks_record=strshocks(beta_gibbs,sigma_gibbs,Y,X,infoZ.n,infoZ.k,It);
    
    %% BLOCK 4: HD
    hd_record=hd(strshocks_record,struct_irf_record,Y,infoZ.n,infoZ.T,It);
    hd_save(infoZ.n,names_endo,decimaldates,hd_record,Y,signreslabels,model,datapath,infoZ.T,It);
    
    %% BLOCK 5: FEVD
    fevd_record=fevd(struct_irf_record,FEVD_horizon,infoZ.n,It);
    fevd_save(fevd_record,endo,signreslabels,infoZ.n,FEVD_horizon,datapath,It,model)

end