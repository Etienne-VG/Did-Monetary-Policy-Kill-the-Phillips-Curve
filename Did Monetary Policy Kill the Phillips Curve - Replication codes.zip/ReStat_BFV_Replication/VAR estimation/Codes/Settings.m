%% Setting script

% All models
if model==1.1 || model==1.2 || model==1.3 % (a) Baseline as a reference
    varendo='Inflation Output_gap';
    names_endo={'Inflation','Output gap'};
    if model==1.1
        startdate='1968q4'; enddate='1994q4'; % Sample 1    
    elseif model==1.2
        startdate='1994q1'; enddate='2019q4'; % Sample 2
    end
elseif model==2.1 || model==2.2 || model==2.3 % (b) Cyclically sensitive inflation as a measure of inflation (Stock and Watson (2020))
    varendo='Inflation Output_gap';
    names_endo={'Inflation','Output gap'};
    if model==2.1
        startdate='1968q4'; enddate='1994q4'; % Sample 1    
    elseif model==2.2
        startdate='1994q1'; enddate='2019q1'; % Sample 2  
    end
elseif model==3.1 || model==3.2 || model==3.3 % (c) Unemployment rate as a measure of real economic activity
    varendo='Inflation Unemployment';
    names_endo={'Inflation','Unemployment'};
    if model==3.1
        startdate='1968q4'; enddate='1994q4'; % Sample 1    
    elseif model==3.2
        startdate='1994q1'; enddate='2019q4'; % Sample 2
    end
elseif model==4.1 || model==4.2 || model==4.3 % (d) Unemployment gap from u∗ (trend) as a measure of real economic activity
    varendo='Inflation Unemployment_gap';
    names_endo={'Inflation','Unemployment gap'};
    if model==4.1
        startdate='1968q4'; enddate='1994q4'; % Sample 1    
    elseif model==4.2
        startdate='1994q1'; enddate='2019q4'; % Sample 2  
    end
elseif model==5.1 || model==5.2 || model==5.3 % (e) Sample split in 1998Q4 as in Jørgensen and Lansing (2023)
    varendo='Inflation Output_gap';
    names_endo={'Inflation','Output gap'};
    if model==5.1
        startdate='1959q1'; enddate='1998q4'; % Sample 1    
    elseif model==5.2
        startdate='1998q1'; enddate='2019q2'; % Sample 2
    end
elseif model==6.1 || model==6.2 || model==6.3 % (f) Second sample ends in 2008Q4
    varendo='Inflation Output_gap';
    names_endo={'Inflation','Output gap'};
    if model==6.1
        startdate='1968q4'; enddate='1994q4'; % Sample 1    
    elseif model==6.2
        startdate='1994q1'; enddate='2008q4'; % Sample 2 
    end
elseif model==7.1 || model==7.2 || model==7.3 % (g) Baseline augmented with SPF expectations
    varendo='Inflation Inf_exp Output_gap';
    names_endo={'Inflation','Inf. exp.','Output gap'};
    if model==7.1
        startdate='1968q4'; enddate='1994q4'; % Sample 1    
    elseif model==7.2
        startdate='1994q1'; enddate='2019q4'; % Sample 2
    end
elseif model==8.1 || model==8.2 || model==8.3 % (h) Baseline augmented with Michigan expectations
    varendo='Inflation Inf_exp Output_gap';
    names_endo={'Inflation','Inf. exp.','Output gap'};
    if model==8.1
        startdate='1978q1'; enddate='1994q4'; % Sample 1    
    elseif model==8.2
        startdate='1994q1'; enddate='2019q4'; % Sample 2 
    end
elseif model==9.1 || model==9.2 || model==9.3 % (i) CPI inflation and Michigan expectations
    varendo='Inflation Inf_exp Output_gap';
    names_endo={'Inflation','Inf. exp.','Output gap'};
    if model==9.1
        startdate='1978q1'; enddate='1994q4'; % Sample 1    
    elseif model==9.2
        startdate='1994q1'; enddate='2019q4'; % Sample 2
    end
elseif model==10.1 || model==10.2 || model==10.3 % Small VAR with MP shock: Output gap (CBO), Inflation (GDP Deflator), Fed Funds rate
    varendo='Inflation Output_gap Fed_funds';
    names_endo={'Inflation','Output gap','Fed Funds rate'};
    names_endo_IRF={'Inflation','Output gap','Fed Funds rate'};
    if model==10.1
        startdate='1968q4'; enddate='1994q4'; % Sample 1    
    elseif model==10.2
        startdate='1994q1'; enddate='2019q4'; % Sample 2
    end
elseif model==11.1 || model==11.2 || model==11.3 % (k) Three-variable SVAR with the shadow rate as computed by Wu and Xia 
    varendo='Inflation Output_gap ShadowRate';
    names_endo={'Inflation','Output gap','Shadow rate'};
    if model==11.1
        startdate='1968q4'; enddate='1994q4'; % Sample 1    
    elseif model==11.2
        startdate='1994q1'; enddate='2019q4'; % Sample 2
    end
elseif model==12.1 || model==12.2 || model==12.3 % (l) Four-variable SVAR with the shadow rate and the real wage
    varendo='Inflation Output_gap ShadowRate RealWage';
    names_endo={'Inflation','Output gap','Shadow rate','Real Wage Inflation'};
    if model==12.1
        startdate='1968q4'; enddate='1994q4'; % Sample 1    
    elseif model==12.2
        startdate='1994q1'; enddate='2019q4'; % Sample 2
    end
end
n=size(names_endo,2);

%%%%%%%%%%%%%%%%%
% Options %
%%%%%%%%%%%%%%%%%

% number of lags
lags=4;
% inclusion of a constant (1=yes, 0=no)
const=1;
% total number of iterations for the Gibbs sampler (no burn-out required)
It=10000;
% horizon of the fevd
FEVD_horizon = 24;