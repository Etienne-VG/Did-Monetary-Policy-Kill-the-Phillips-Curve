function [success,respect_SR,fail_shock]=checksignres(ortirfmatrix,Scell,horizon)

% ortirfmatrix(h,i)=(variable,shock)
fail_shock=[];
respect_SR=ones(size(ortirfmatrix)); % (nbshocks max,variable,shock)
n=size(ortirfmatrix(:,:,1),1);
    
for i=1:size(Scell,2) % Loop over shocks
    for j=1:size(Scell{1,i},1) % Loop over number of variables restricted for shock i
        h=find(Scell{1,i}(j,:)); % index of variable restricted
        if h>n
            H=horizon; % issue if horizon >2
        else
            H=1;
        end
        if (ortirfmatrix(h-(H-1)*n,i,H)*Scell{1,i}(j,h))<0 % Change horizon if restrictions are at later period than the first
            respect_SR(j,i,h)=0;
            fail_shock=[fail_shock,i]; % Record which shock failed
        end  
    end    
end

if all(respect_SR(:)) % if respect contains a zero then one restriction is breached
    success=1;
else    
    success=0;
end

end