function decimaldates1=gendates(names,lags,startdate,enddate)

% preliminary tasks
% define date strings
datestrings=names(2:end,1);

% PHASE 1: CREATION OF DECIMAL DATES AND DATE STRINGS FOR THE ESTIMATION SAMPLE (DECIMALDATES1, STRINGDATES1)
% first identify the year and quarter of the initial date
startyear=str2num(startdate(1,1:4));
startquarter=str2num(startdate(1,6));
% proceed similarly for the year and quarter of the final date
endyear=str2num(enddate(1,1:4));
endquarter=str2num(enddate(1,6));
% initiate the decimal value vector and the string cell
decimaldates1=[];
% create the decimal vector from start date up to the penultimate year
year=startyear;
quarter=startquarter;
   while year<=endyear-1
      while quarter<=4
          % decimaldates1=[decimaldates1;year+(quarter-1)/4]; % 1980Q2=1980.25 (date at the start of the periode)
          decimaldates1=[decimaldates1;year+(quarter)/4]; % 1980Q2=1980.50 (date at the end of the periode)
          temp=[num2str(year) 'q' num2str(quarter)];
          quarter=quarter+1;
      end
   quarter=1;
   year=year+1;
   end
% complete with final year  
   while quarter<=endquarter
       %decimaldates1=[decimaldates1;year+(quarter-1)/4]; % 1980Q2=1980.25 (date at the start of the periode)
       decimaldates1=[decimaldates1;year+(quarter)/4]; % 1980Q2=1980.50 (date at the end of the periode)
       temp=[num2str(year) 'q' num2str(quarter)];
       quarter=quarter+1;
   end
% finally, trim a number of initial periods equal to the number of lags, as these periods will be used to create initial conditions
decimaldates1=decimaldates1(lags+1:end,:);

end


