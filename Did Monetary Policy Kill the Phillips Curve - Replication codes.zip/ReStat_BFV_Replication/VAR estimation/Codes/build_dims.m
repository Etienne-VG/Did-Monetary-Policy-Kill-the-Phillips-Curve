function infoZ=build_dims(infoZ,Zcell)

% dim counts the dimension of the manifold defined over Q_{1} 
dim1=0;
for i=1:infoZ.n
    dim1=dim1+infoZ.n-(i-1+size(Zcell{i},1)); % only structural zeros, not the proxy ones
end
infoZ.dim1=dim1;

% gets a random W1 related to the applicability of Theorem 3. Appendix A3 in Inference Based on Sign and Zero Restrictions: Theory and Applications.
W1=cell(infoZ.n,1); 
for j=1:infoZ.n
    W1{j}=randn(infoZ.n-(j-1+size(Zcell{j},1)),infoZ.n);
end
infoZ.W1=W1;