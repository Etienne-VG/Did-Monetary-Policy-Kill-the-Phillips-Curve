function [names,data_endo]=gensample(startdate,enddate,endo,model)

[ data, names ] = xlsread( 'data.xlsx',strcat('data',num2str(model)));

[ r, c ] = size( data );
for ii = 1:r
    for jj = 1:c
        temp = data( ii, jj );
        if ( temp <= inf ) == 0
            NaNvariable = names{ 1, jj + 1 };
            NaNdate = names{ ii + 1, 1 };
            message = [ 'Error: variable ', NaNvariable, ' at date ', NaNdate, ' (and possibly other sample entries) is identified as NaN. Please check your Excel spreadsheet: entry may be blank or non-numerical.' ];
            msgbox( message );
            error( 'programme termination: data error' );
        end 
    end 
end 

datestrings = names( 2:end , 1 );
startlocation = find( strcmp( datestrings, startdate ) );
endlocation = find( strcmp( datestrings, enddate ) );
if isempty( startlocation )
    msgbox( 'Error: unknown start date for the sample. Please check your sample start date (remember that names are case-sensitive).' );
    error( 'programme termination: date error' );
elseif isempty( endlocation )
    msgbox( 'Error: unknown end date for the sample. Please check your sample end date (remember that names are case-sensitive).' );
    error( 'programme termination: date error' );
end 
if startlocation >= endlocation == 1
    msgbox( 'Error: inconsistency between the start and end dates. The start date must be anterior to the end date.' );
    error( 'programme termination: date error' );
end 

variablestrings = names( 1, 2:end  );
numendo = size( endo, 1 );

for ii = 1:numendo
    var = endo{ ii, 1 };
    check = find( strcmp( variablestrings, var ) );
    if isempty( check ) == 1
        message = [ 'Error: endogenous variable ', var, ' cannot be found on the excel data spreadsheet.' ];
        msgbox( message );
        error( 'programme termination: data error' );
    end 
    endolocation( ii, 1 ) = find( strcmp( variablestrings, endo( ii, 1 ) ) );
end 

data_endo = [  ];
for ii = 1:numendo
    data_endo = [ data_endo, data( startlocation:endlocation, endolocation( ii, 1 ) ) ];
end 

end

