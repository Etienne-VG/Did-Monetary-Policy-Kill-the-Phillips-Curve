function [irfmatrix,ortirfmatrix]=irfsim(B,D,n,m,p,horizon)
                 
% Pre-allocate
irfmatrix=NaN(horizon,n,n);

% deal with shocks in turn
for ii=1:n
    
    % create a matrix of zeros of dimension p*n
    Y=zeros(p,n);

    Y(p,ii)=1; % one standard deviation shock

   % repeat the algorithm from period T+1 to period T+h
   for jj=1:horizon-1

       % step 1
       % use the function lagx to obtain the matrix temp, containing the endogenous regressors
       temp=lagx(Y,p-1);

       % step 2
       % define the vector X
       X=[temp(end,:),zeros(1,m)];

       % step 3
       % obtain the predicted value for T+jj
       yp=X*B;

       % step 4
       % concatenate yp at the top of Y
       Y=[Y;yp];

   end

   % consider 'Y' and trim the (p-1) initial periods: what remains is the series of IRFs for period T to period T+h-1
   irfmatrix(:,:,ii)=Y(p:end,:); % irfmatrix(period,variable,shock)=Y(period,variable);
   
end

% reorder correctly
irfmatrix=permute(irfmatrix,[2,3,1]); % irfmatrix(variable,shock,period)

% obtain now orthogonalised IRFs
ortirfmatrix=pagemtimes(irfmatrix,repmat(D,1,1,horizon)); % ortirfmatrix(shock,variable,period)

end
