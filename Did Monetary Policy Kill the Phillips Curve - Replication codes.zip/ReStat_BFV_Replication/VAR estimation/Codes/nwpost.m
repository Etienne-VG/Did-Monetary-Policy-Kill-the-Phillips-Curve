function SBVAR=nwpost(B0,phi0,S0,alpha0,X,Y,infoZ)

% obtain alphabar
alphabar=infoZ.T+alpha0;

% compute phibar
invphi0=zeros(size(phi0,1),size(phi0,1));
phibar=(invphi0+X'*X)\eye(size(invphi0+X'*X,1));
invphibar=phibar\eye(size(phibar,1));

% compute Bbar
Bbar=phibar*(invphi0*B0+X'*Y); 

% vectorise to obtain betabar
betabar=Bbar(:);

% obtain Sbar
Sbar=Y'*Y+S0+B0'*invphi0*B0-Bbar'*invphibar*Bbar;

% stabilise Sbar to avoid numerical errors
Sbar=(Sbar'+Sbar)/2;

SBVAR.Bbar=Bbar;
SBVAR.betabar=betabar;
SBVAR.phibar=phibar;
SBVAR.invphibar=invphibar;
SBVAR.Sbar=Sbar;
SBVAR.alphabar=alphabar;
    
end
