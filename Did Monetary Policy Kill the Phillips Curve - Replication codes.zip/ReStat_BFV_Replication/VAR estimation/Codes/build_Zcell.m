function [Zcell,Zstructural]=build_Zcell(Zcell,Zstructural,n)

% Build Zcell & Zstructural
for ii=1:n
    if isempty(Zcell{1,ii})
        Zcell{1,ii}=zeros(0,n);
    end
    if isempty(Zstructural{1,ii})
        Zstructural{1,ii}=zeros(0,n);
    end
end

end