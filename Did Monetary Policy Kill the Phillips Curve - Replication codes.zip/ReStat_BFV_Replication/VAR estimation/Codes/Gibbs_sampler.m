function [beta_gibbs,sigma_gibbs,q_gibbs,struct_irf_record,count_draws]=Gibbs_sampler(infoZ,SBVAR,signrestable,signresperiods,It)

% Code based on ARW (2018)

%% Preliminary tasks
% Extract restrictions from the excel spreadsheet
infoZ=sign_restrictions_extract(signrestable,signresperiods,infoZ);
% Pre-allocate
beta_gibbs=NaN(infoZ.q,It);
sigma_gibbs=NaN(infoZ.n*infoZ.n,It);
q_gibbs=NaN(infoZ.n*infoZ.n,It);
nb_draw=0;

%% Gibbs sampler (no burnout period as Natural Conjugate prior or Normal-Diffuse)
% Start timer
tic;
% Show progression bar
WaitMessage = parfor_wait(It,'Waitbar',true,'ReportInterval',1);
for ii=1:It
    % Run Algorithm
    [beta,sigma,Q,draw]=algorithm(infoZ,SBVAR);
    
    % Record successful coefficients
    beta_gibbs(:,ii)=beta; % Beta
    sigma_gibbs(:,ii)=sigma; % Sigma
    q_gibbs(:,ii)=Q; % Q

    % Record total number of draw
    nb_draw=nb_draw+draw;
    % Update progress by one iteration
    WaitMessage.Send;
end
% Close progress bar
WaitMessage.Destroy

%% store IRF
% Generate the structural IRFs for draw ii
ortirfmatrix=NaN(infoZ.n,infoZ.n,infoZ.T,It);
% Loop over number of draws
for ii=1:It
    [~,ortirfmatrix(:,:,:,ii)]=irfsim(reshape(beta_gibbs(:,ii),infoZ.k,infoZ.n),reshape(sigma_gibbs(:,ii),infoZ.n,infoZ.n),infoZ.n,infoZ.m,infoZ.p,infoZ.T); % Compute orthogonalized IRF
end
% Store the IRFs correctly
struct_irf_record=cell(infoZ.n,infoZ.n);
% Loop over variables
for kk=1:infoZ.n
   % Loop over shocks
   for ll=1:infoZ.n
       struct_irf_record{kk,ll}(:,:)=transpose(squeeze(ortirfmatrix(kk,ll,:,:))); % struct_irf_record is {nshock,nvar}(ndraws,T) and ortirfmatrix is (nshock,nvar,T,ndraw)
   end
end

%% Gather in an object
count_draws.nb_draw=nb_draw;

end