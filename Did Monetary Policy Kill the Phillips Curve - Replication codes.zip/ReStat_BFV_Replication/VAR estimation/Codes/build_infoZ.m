function [infoZ,Y,X]=build_infoZ(data_endo,const,lags)

% first compute p, the number of lags in the model
p=lags;

% then compute n, the number of endogenous variables in the model; it is simply the number of columns in the matrix 'data_endo'
n=size(data_endo,2); % n in ARW (2021)

% if the constant has been selected, augment the matrix of exogenous with a column of ones (number of rows equal to number of rows in data_endo)
if const==1
    data_exo=ones(size(data_endo,1),1);
    % if no constant was included, do nothing
end

% compute m, the number of exogenous variables in the model
% if data_exo is empty, set m=0
if isempty(data_exo)==1
    m=0; % etilde-const in ARW (2021)
    % if data_exo is not empty, count the number of exogenous variables that will be included in the model
else
    m=size(data_exo,2); % etilde-const in ARW (2021)
    % Also, trim a number initial rows equal to the number of lags, as they will be suppressed from the endogenous as well to create initial conditions
    data_exo=data_exo(p+1:end,:);
end

% determine k, the number of parameters to estimate in each equation; it is equal to np+m
k=n*p+m; % mtilde in ARW (2021)

% determine q, the total number of VAR parameters to estimate; it is equal to n*k
q=n*k;

% obtain X as defined in (1.1.8)
% to do so, use the lagx function on the data matrix
% this will basically return the matrix X without the exogenous variables, but with n additional columns of current period data
temp=lagx(data_endo,lags);

% to build X, take off the n initial columns of current data, and concatenate the exogenous
X=[temp(:,n+1:end),data_exo];

% Define T, the number of periods of the model, as the number of rows of X
T=size(X,1);

% save the n first columns of temp as Y, as defined in (1.1.8)
Y=temp(:,1:n);

infoZ.T=T; % number of observations
infoZ.n=n; % number of endogeneous variables
infoZ.k=k; % number of predetermined variables: k=n*p+m
infoZ.p=p; % number of lags
infoZ.m=m; % number of exogeneous variables (including the constant)
infoZ.q=q; % number of parameters in total