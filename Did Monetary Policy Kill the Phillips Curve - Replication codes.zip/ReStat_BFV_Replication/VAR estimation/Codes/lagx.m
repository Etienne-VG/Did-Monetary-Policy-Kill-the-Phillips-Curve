function out=lagx(X,p)

% Compute the number of rows and columns of input matrix X, and save the values as r and c
[r,c]=size(X);

% start with the reformating of the original vectors
out(:,1:c)=X(p+1:r,:);

% treat each lag consecutively
for ii=1:p
    out(:,c*ii+1:c*(ii+1))=X(p+1-ii:r-ii,:);
end