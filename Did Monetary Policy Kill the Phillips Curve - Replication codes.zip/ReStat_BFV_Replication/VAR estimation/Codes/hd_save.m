function []=hd_save(n,endo,decimaldates1,hd_record,Y,signreslabels,model,datapath,T,It)

% Build 4D matrix of historical decompositions
hd_record = hd_record';
HD_all = NaN(n+1,T,n,It);
for i=1:n % loop over variables
    for j=1:n+1 % loop over shocks
        for k=1:It % loop over draws
            HD_all(j,:,i,k)=hd_record{j,i}(k,:); % HD(shock,time,variable,draw) % Lower bound and upper bound unused here
        end
    end
end

% take point-wise median
HD_median = median(HD_all,4);

% shock names
names = cell(n);
for i=1:n
    names{i}=signreslabels{i,1};
end
names{n+1}='Initial conditions'; 

% Save conditional data
if model==1.1 || model==1.2 || model==1.3 ||...
       model==2.1 || model==2.2 || model==2.3 ||...
       model==5.1 || model==5.2 || model==5.3 ||...
       model==6.1 || model==6.2 || model==6.3  % model 1,2,5,6
    i2=find(strcmp(cellstr(endo),'Inflation')==1);
    i3=find(strcmp(cellstr(endo),'Output gap')==1);
elseif model==3.1 || model==3.2 || model==3.3 % model 3
    i2=find(strcmp(cellstr(endo),'Inflation')==1);
    i3=find(strcmp(cellstr(endo),'Unemployment')==1);
elseif model==4.1 || model==4.2 || model==4.3 % model 4
    i2=find(strcmp(cellstr(endo),'Inflation')==1);
    i3=find(strcmp(cellstr(endo),'Unemployment gap')==1);
elseif model==7.1 || model==7.2 || model==7.3 ||...
   model==8.1 || model==8.2 || model==8.3 ||...
   model==9.1 || model==9.2 || model==9.3 % models 7,8,9
    i2=find(strcmp(cellstr(endo),'Inflation')==1);
    i3=find(strcmp(cellstr(endo),'Output gap')==1);
    i4=find(strcmp(cellstr(endo),'Inf. exp.')==1);
elseif model==10.1 || model==10.2 || model==10.3 % model 10
    i2=find(strcmp(cellstr(endo),'Inflation')==1);
    i3=find(strcmp(cellstr(endo),'Output gap')==1);
    i4=find(strcmp(cellstr(endo),'Fed Funds rate')==1);
elseif model==11.1 || model==11.2 || model==11.3 % model 11
    i2=find(strcmp(cellstr(endo),'Inflation')==1);
    i3=find(strcmp(cellstr(endo),'Output gap')==1);
    i4=find(strcmp(cellstr(endo),'Shadow rate')==1);
elseif model==12.1 || model==12.2 || model==12.3 % model 12
    i2=find(strcmp(cellstr(endo),'Inflation')==1);
    i3=find(strcmp(cellstr(endo),'Output gap')==1);
    i4=find(strcmp(cellstr(endo),'Shadow rate')==1);
    i5=find(strcmp(cellstr(endo),'Real Wage Inflation')==1);
end

%% Build conditional data matrices
% case 2 variables VAR
if model==1.1 || model==1.2 || model==1.3 ||...
    model==2.1 || model==2.2 || model==2.3 ||...
    model==3.1 || model==3.2 || model==3.3 ||...
    model==4.1 || model==4.2 || model==4.3 ||...
    model==5.1 || model==5.2 || model==5.3 ||...
    model==6.1 || model==6.2 || model==6.3 % model 1,2,3,4,5,6
   
   conditional_data_all_draws=repmat(decimaldates1(:,1),1,1,It);
   conditional_data_median_draw=decimaldates1(:,1);
   conditional_data_names=cellstr('Dates');
   for i=1:n+1 % loop over shocks
       
       conditional_data_all_draws=[conditional_data_all_draws,reshape(squeeze(HD_all(i,:,i2,:)),T,1,It),reshape(squeeze(HD_all(i,:,i3,:)),T,1,It)];
       conditional_data_median_draw=[conditional_data_median_draw,HD_median(i,:,i2)',HD_median(i,:,i3)'];
       conditional_data_names=[conditional_data_names,strcat(names{i},{' '},endo{i2}),strcat(names{i},{' '},endo{i3})];
   end
   conditional_data_all_draws=[conditional_data_all_draws,repmat(Y(:,i2),1,1,It),repmat(Y(:,i3),1,1,It)];
   conditional_data_median_draw=[conditional_data_median_draw,Y(:,i2),Y(:,i3)];
   conditional_data_names=[conditional_data_names,endo{i2},endo{i3}];
   conditional_data_all_draws=[repmat(conditional_data_names,1,1,It);num2cell(conditional_data_all_draws)];
   conditional_data_median_draw=[conditional_data_names;num2cell(conditional_data_median_draw)];

% case 3 variables VAR
elseif model==7.1 || model==7.2 || model==7.3 ||...
    model==8.1 || model==8.2 || model==8.3 ||...
    model==9.1 || model==9.2 || model==9.3 ||...
    model==10.1 || model==10.2 || model==10.3 ||...
    model==11.1 || model==11.2 || model==11.3 % model 7,8,9,10,11

   conditional_data_all_draws=repmat(decimaldates1(:,1),1,1,It);
   conditional_data_median_draw=decimaldates1(:,1);
   conditional_data_names=cellstr('Dates');
   for i=1:n+1 % loop over shocks
       
       conditional_data_all_draws=[conditional_data_all_draws,reshape(squeeze(HD_all(i,:,i2,:)),T,1,It),reshape(squeeze(HD_all(i,:,i3,:)),T,1,It),reshape(squeeze(HD_all(i,:,i4,:)),T,1,It)];
       conditional_data_median_draw=[conditional_data_median_draw,HD_median(i,:,i2)',HD_median(i,:,i3)',HD_median(i,:,i4)'];
       conditional_data_names=[conditional_data_names,strcat(names{i},{' '},endo{i2}),strcat(names{i},{' '},endo{i3}),strcat(names{i},{' '},endo{i4})];
   end
   conditional_data_all_draws=[conditional_data_all_draws,repmat(Y(:,i2),1,1,It),repmat(Y(:,i3),1,1,It),repmat(Y(:,i4),1,1,It)];
   conditional_data_median_draw=[conditional_data_median_draw,Y(:,i2),Y(:,i3),Y(:,i4)];
   conditional_data_names=[conditional_data_names,endo{i2},endo{i3},endo{i4}];
   conditional_data_all_draws=[repmat(conditional_data_names,1,1,It);num2cell(conditional_data_all_draws)];
   conditional_data_median_draw=[conditional_data_names;num2cell(conditional_data_median_draw)];

% case 3 variables VAR
elseif model==12.1 || model==12.2 || model==12.3 % model 12
   
   conditional_data_all_draws=repmat(decimaldates1(:,1),1,1,It);
   conditional_data_median_draw=decimaldates1(:,1);
   conditional_data_names=cellstr('Dates');
   for i=1:n+1 % loop over shocks
       
       conditional_data_all_draws=[conditional_data_all_draws,reshape(squeeze(HD_all(i,:,i2,:)),T,1,It),reshape(squeeze(HD_all(i,:,i3,:)),T,1,It),reshape(squeeze(HD_all(i,:,i4,:)),T,1,It),reshape(squeeze(HD_all(i,:,i5,:)),T,1,It)];
       conditional_data_median_draw=[conditional_data_median_draw,HD_median(i,:,i2)',HD_median(i,:,i3)',HD_median(i,:,i4)',HD_median(i,:,i5)'];
       conditional_data_names=[conditional_data_names,strcat(names{i},{' '},endo{i2}),strcat(names{i},{' '},endo{i3}),strcat(names{i},{' '},endo{i4}),strcat(names{i},{' '},endo{i5})];
   end
   conditional_data_all_draws=[conditional_data_all_draws,repmat(Y(:,i2),1,1,It),repmat(Y(:,i3),1,1,It),repmat(Y(:,i4),1,1,It),repmat(Y(:,i5),1,1,It)];
   conditional_data_median_draw=[conditional_data_median_draw,Y(:,i2),Y(:,i3),Y(:,i4),Y(:,i5)];
   conditional_data_names=[conditional_data_names,endo{i2},endo{i3},endo{i4},endo{i5}];
   conditional_data_all_draws=[repmat(conditional_data_names,1,1,It);num2cell(conditional_data_all_draws)];
   conditional_data_median_draw=[conditional_data_names;num2cell(conditional_data_median_draw)];

end

% save mat files
Filename_all_draws=strcat('conditional_data_all_draws_model_',num2str(model),'.mat');
Filename_median=strcat('conditional_data_median_draw_model_',num2str(model),'.mat');
cd(strcat(datapath,'/Results'));
save(Filename_all_draws,'conditional_data_all_draws');
save(Filename_median,'conditional_data_median_draw');
cd(strcat(datapath,'/Codes'));

end