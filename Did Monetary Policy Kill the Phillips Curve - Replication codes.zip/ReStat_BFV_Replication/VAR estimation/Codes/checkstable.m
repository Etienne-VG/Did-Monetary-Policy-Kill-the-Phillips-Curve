function [stationary,eigmodulus]=checkstable(B,n,p)

% recover the first matrix row of F
temp1=B(1:n*p,:)';

% recover the other two parts of F
temp2=eye(n*(p-1));
temp3=zeros(n*(p-1),n);

% obtain F
F=[temp1;temp2 temp3];

% then compute the absolute values of the eigenvalues of F and sort them by decreasing order
eigmodulus=sort(abs(eig(F)),'descend');

if eigmodulus(1,1)<0.999
    stationary=1;
else
    stationary=0;
end